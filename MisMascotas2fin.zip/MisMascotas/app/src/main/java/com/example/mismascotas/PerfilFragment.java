package com.example.mismascotas;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class PerfilFragment extends Fragment {
    private ArrayList<Mascota> mascotas;
    private RecyclerView listaMascotas;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //infllamos el fragment
        View v = inflater.inflate(R.layout.fragment_perfil, container, false);
        //instanciamos el reciclerview
        listaMascotas = (RecyclerView) v.findViewById(R.id.rvMascotas2);
        //creamos un linearlayout manager para las listas
        GridLayoutManager glm = new GridLayoutManager(getActivity(), 2);
        glm.setOrientation(LinearLayoutManager.VERTICAL);
        listaMascotas.setLayoutManager(glm);//hacemos que el reciclerview se porte como linearL
        inicializarListaMascotas();
        inicializaAdaptador();
        return v;
        //return super.onCreateView(inflater, container, savedInstanceState);
    }

    public PerfilAdaptador adaptador;

    public void inicializaAdaptador() {
        //inicializamos la instancia de listacontactos
        //ContactoAdaptador adaptador = new ContactoAdaptador(contactos,this);
        // listaContactos.setAdapter(adaptador);//seteamos el adapter
        adaptador = new PerfilAdaptador(mascotas, getActivity());
        listaMascotas.setAdapter(adaptador);
    }

    public void inicializarListaMascotas() {
        mascotas = new ArrayList<Mascota>();//array objeto contactos
        mascotas.add(new Mascota(R.drawable.ic1, "Puffy", "Buldog", 2));
        mascotas.add(new Mascota(R.drawable.ic1, "Puffy", "Buldog", 4));
        mascotas.add(new Mascota(R.drawable.ic1, "Puffy", "Buldog", 1));
        mascotas.add(new Mascota(R.drawable.ic1, "Puffy", "Buldog", 3));
        mascotas.add(new Mascota(R.drawable.ic1, "Puffy", "Buldog", 2));
        mascotas.add(new Mascota(R.drawable.ic1, "Puffy", "Buldog", 5));
    }
}
