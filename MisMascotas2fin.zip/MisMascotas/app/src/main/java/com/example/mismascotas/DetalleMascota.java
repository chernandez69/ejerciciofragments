package com.example.mismascotas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;

public class DetalleMascota extends AppCompatActivity {
    private TextView tvNombre;
    private TextView tvRaza;
    private TextView tvRatin;
    ArrayList<Mascota> mascotas;
    //declaramos el reciclerview
    private RecyclerView listaMascotasRateadas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_mascota);
         //cargamos el recicler 5 mascotas
        androidx.appcompat.widget.Toolbar miActionBar = findViewById(R.id.miActionBar2);
        setSupportActionBar(miActionBar);//para que se vea bien en todas las pantalla}
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);//habilitar boton back
        //instanciamos el reciclerview
        listaMascotasRateadas = (RecyclerView) findViewById(R.id.rvdetallaMascotas);
        //creamos un linearlayout manager para las listas
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        // GridLayoutManager glm = new GridLayoutManager(this, 2);
        listaMascotasRateadas.setLayoutManager(llm);//hacemos que el reciclerview se porte como linearL
        inicializarListaMascotas();
        inicializaAdaptador();
    }//oncreate

    public MascotaAdaptador adaptador;
    public void inicializaAdaptador(){
        //inicializamos la instancia de listacontactos
        MascotaAdaptador adaptador = new MascotaAdaptador(mascotas,this);
        listaMascotasRateadas.setAdapter(adaptador);//seteamos el adapter
        // adaptador = new MascotaAdaptador(mascotas, this);
        //listaMascotas.setAdapter(adaptador);
    }//inicializar adaptador

    public void inicializarListaMascotas(){
        mascotas = new ArrayList<Mascota>();//array objeto contactos
        mascotas.add(new Mascota(R.drawable.ic1,"Puffy", "Buldog",0));
        mascotas.add(new Mascota(R.drawable.ic2,"Ruffo", "Coker Spanish",0));
        mascotas.add(new Mascota(R.drawable.ic3,"Zulingo", "Fox Terrier", 0));
        mascotas.add(new Mascota(R.drawable.ic4,"Tobby", "Labrador",0));
        mascotas.add(new Mascota(R.drawable.ic5,"Hacho", "Pug",0));
    }//listamascotas rateadas
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {//control button back
         if (keyCode==KeyEvent.KEYCODE_BACK){
             Intent intent = new Intent(DetalleMascota.this, MainActivity.class);
             startActivity(intent);
         }
        return super.onKeyDown(keyCode, event);
    }//onkeydown
}//detallemascota