package com.example.mismascotas;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

    public class fragment_recyclerview extends Fragment {
        private ArrayList<Mascota> mascotas;
        private RecyclerView listaMascotas;

        @Nullable
        @Override
        public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
            //infllamos el fragment
            View v = inflater.inflate(R.layout.fragment_recyclerview, container, false);
            //instanciamos el reciclerview
            listaMascotas = (RecyclerView) v.findViewById(R.id.rvMascotas);
            //creamos un linearlayout manager para las listas
            LinearLayoutManager glm = new LinearLayoutManager(getActivity());
            glm.setOrientation(LinearLayoutManager.VERTICAL);
            listaMascotas.setLayoutManager(glm);//hacemos que el reciclerview se porte como linearL
            inicializarListaMascotas();
            inicializaAdaptador();
            return v;
            //return super.onCreateView(inflater, container, savedInstanceState);
        }

        public MascotaAdaptador adaptador;
        public void inicializaAdaptador() {
            //inicializamos la instancia de listacontactos
            //ContactoAdaptador adaptador = new ContactoAdaptador(contactos,this);
            // listaContactos.setAdapter(adaptador);//seteamos el adapter
            adaptador = new MascotaAdaptador(mascotas, getActivity());
            listaMascotas.setAdapter(adaptador);
        }

        public void inicializarListaMascotas() {
            mascotas = new ArrayList<Mascota>();//array objeto contactos
            mascotas.add(new Mascota(R.drawable.ic1, "Puffy", "Buldog", 0));
            mascotas.add(new Mascota(R.drawable.ic2, "Ruffo", "Coker Spanish", 0));
            mascotas.add(new Mascota(R.drawable.ic3, "Zulingo", "Fox Terrier", 0));
            mascotas.add(new Mascota(R.drawable.ic4, "Tobby", "Labrador", 0));
            mascotas.add(new Mascota(R.drawable.ic5, "Hacho", "Pug", 0));
            mascotas.add(new Mascota(R.drawable.ic6, "Loly", "Siberiano", 0));
        }
    }