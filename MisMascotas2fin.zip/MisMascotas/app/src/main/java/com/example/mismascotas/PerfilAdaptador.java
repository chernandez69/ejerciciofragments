package com.example.mismascotas;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PerfilAdaptador extends RecyclerView.Adapter<PerfilAdaptador.PerfilViewHolder>{
    ArrayList<Mascota> mascotas;
    Activity activity;
    int rata=1;
    public PerfilAdaptador(ArrayList<Mascota> mascotas, Activity activity){
        this.mascotas = mascotas;
        this.activity = activity;
    }

    //inflar el layout y lo pasara al viewholder para que obtenga los views
    @NonNull
    @Override
    public PerfilViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_perfil, parent, false);
        return new PerfilViewHolder(v) ;//pasamos el layout creado como un view
    }
    //asocia cada elemento de la vista con cada view
    @Override
    public void onBindViewHolder(@NonNull final PerfilViewHolder mascotaViewHolder, final int position) {
        //seteamos cada uno de los elementos que trae la lista
        final Mascota mascota = mascotas.get(position);
        mascotaViewHolder.imgFoto.setImageResource(mascota.getFoto());//acceder al get foto
       // mascotaViewHolder.tvNombreCV.setText(mascota.getNombre());
        mascotaViewHolder.tvRatinCV.setText(String.valueOf(mascota.getRatin()));
    }

    @Override
    public int getItemCount() {//cantidad de elementos de la lista
        return mascotas.size();
    }

    public static class PerfilViewHolder extends RecyclerView.ViewHolder{
        private ImageView imgFoto;
        private TextView tvNombreCV;
        private TextView tvRatinCV;

        public PerfilViewHolder(@NonNull View itemView) {
            super(itemView);
            imgFoto      = (ImageView) itemView.findViewById(R.id.imgfoto);
            //tvNombreCV   = (TextView) itemView.findViewById(R.id.tvNombreCV);
            tvRatinCV    = (TextView) itemView.findViewById(R.id.tvRatinCV);
        }
    }
}